package com.example.demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
	@RequestMapping("/hello")
	public String helloQueryString(@RequestParam("name") String name, @RequestParam("age") int age) {
		age += 10;
		return "こんにちは" + name + "さん。 10年後は" + age + "歳ですね！";
	}

	@RequestMapping(value = "/hello/{name}/{age}")
	public String helloPathParameter(@PathVariable("name") String name, @PathVariable("age") int age) {
		age += 10;
		return "こんにちは" + name + "さん。　10年後は" + age + "歳ですね！";
	}
}
