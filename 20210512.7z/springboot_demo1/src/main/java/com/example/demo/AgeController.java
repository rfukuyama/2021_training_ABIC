package com.example.demo;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AgeController {

	@RequestMapping(value = "/birthday/{year}/{month}/{day}")
	public long showAge(@PathVariable("year") int year, @PathVariable("month") int month,
			@PathVariable("day") int day) {
		LocalDate birthday = LocalDate.of(year, month, day);
		LocalDate today = LocalDate.now();

		return ChronoUnit.YEARS.between(birthday, today);
	}
}