package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FormController {
	@RequestMapping(value = "/forms", method = RequestMethod.POST)
	public String showParameter(@RequestParam("name") String name, @RequestParam("pw") String password,
			@RequestParam("gender") String gender, @RequestParam("hobby") int[] hobbies,
			@RequestParam("note") String note) {
		List<String> list = new ArrayList<>();
		list.add("名前: " + name);
		list.add("パスワード: " + password);
		list.add("性別: " + gender);
		list.add("趣味: " + Arrays.toString(hobbies));
		list.add("備考: " + note.replaceAll("\n", "<br>"));
		return String.join("<br>", list);
	}
}
