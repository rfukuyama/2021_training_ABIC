package com.example.demo;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SumController {

	@RequestMapping(value = "/sum/{num}")
	public int sum(@PathVariable("num") int num) {
		int result = 0;
		for (int i = 1; i <= num; i++) {
			result += i;
		}
		return result;
	}
}
