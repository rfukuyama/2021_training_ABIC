package com.example.demo;

import java.util.Random;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OmikujiController {

	@RequestMapping("/omikuji")
	public String omikuji() {
		Random random = new Random();
		int omikuji = random.nextInt(6) + 1;

		switch (omikuji) {
		case 1:
			return "大吉";
		case 2:
			return "小吉";
		case 3:
			return "凶";
		default:
			return "吉";
		}
	}
}
