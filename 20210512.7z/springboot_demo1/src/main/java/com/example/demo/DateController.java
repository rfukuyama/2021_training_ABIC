package com.example.demo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DateController {
	@RequestMapping("/currentDate")
	public String showCurrent() {
		LocalDateTime currentDate = LocalDateTime.now();
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		return currentDate.format(fmt);
	}

	@RequestMapping(value = "/after", method = RequestMethod.POST)
	public String show(@RequestParam("daysParameter") int days) {
		LocalDateTime currentDate = LocalDateTime.now();
		LocalDateTime date = currentDate.plusDays(days);
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		return date.format(fmt);
	}

	@RequestMapping(value = "/afterDays/{days}")
	public String showWithPathVariable(@PathVariable("days") int days) {
		LocalDateTime currentDate = LocalDateTime.now();
		LocalDateTime date = currentDate.plusDays(days);
		DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		return date.format(fmt);
	}

}
