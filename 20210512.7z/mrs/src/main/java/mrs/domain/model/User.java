package mrs.domain.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "usr")
public class User implements Serializable {
	@Id
	private String userId;

	private String password;

	private String firsName;

	private String lastName;

	@Enumerated(EnumType.STRING)
	private RoleName rolename;

}
