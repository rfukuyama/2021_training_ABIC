package mrs.domain.model;

public class RoleName {
	ADMIN, USER
}