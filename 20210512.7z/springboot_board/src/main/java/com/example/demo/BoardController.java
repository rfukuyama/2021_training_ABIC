package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BoardController {

	@Autowired
	HttpSession session;

	@RequestMapping("/")
	public String index() {
		session.invalidate();
		return "board";
	}

	@RequestMapping(value = "/apply", method = RequestMethod.POST)
	public ModelAndView apply(@RequestParam("name") String name, @RequestParam("contents") String contents,
			@RequestParam("face") String face, ModelAndView mv) {
		@SuppressWarnings("unchecked")
		List<Record> allContents = (List<Record>) session.getAttribute("contentsList");
		if (allContents == null) {
			allContents = new ArrayList<>(); // nullの場合は新しく作る
			session.setAttribute("contentsList", allContents);
		}

		if (contents.startsWith("http://") || contents.startsWith("https://")) {
			contents = "<a href=\"" + contents + "\">" + contents + "</a>";
		}
		if (name.equals("") || contents.equals("")) {
			String errorMsg = "名前と書き込みを入力してください";
			mv.addObject("errorMsg", errorMsg);
		} else {
			mv.addObject("errorMsg", "");
			allContents.add(new Record(name, contents, face));
		}

		mv.addObject("allContents", allContents);
		mv.setViewName("board");
		return mv;
	}
}