package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RandomStringController {

	@Autowired
	RandomStringGenerator gen;

	@RequestMapping("/")
	public String index() {
		return "random";
	}

	/**
	 * ランダム文字列生成ボタン押下
	 *
	 * @param charLength 文字列の長さ
	 * @param withNumber 数字を含めるかどうか("1":数字を含める)
	 * @param mv         ModelAndViewのオブジェクト
	 * @return
	 */
	@RequestMapping(value = "/generate", method = RequestMethod.POST)
	public ModelAndView generate(@RequestParam("charLength") int charLength,
			@RequestParam(name = "withNumber", defaultValue = "") String withNumber,
			@RequestParam(name = "withAlphabet", defaultValue = "") String withAlphabet,
			@RequestParam("repet") String repet, ModelAndView mv) {

		// 数字含めるチェックボックスにチェックが入っていればtrue、なければfalse
		boolean withNumFlag = "1".equals(withNumber);
		boolean withAlphaFlag = "1".equals(withAlphabet);
		// ランダム文字列のリストを生成して取得
		List<String> randomStringList = gen.generate(charLength, withNumFlag, withAlphaFlag, repet);
		// Viewに渡す情報をセット
		mv.addObject("randList", randomStringList);
		mv.addObject("withNumber", withNumFlag);
		mv.addObject("withAlphabet", withAlphaFlag);
		mv.addObject("length", charLength);
		mv.addObject("repet", repet);
		// Viewの名前（random.html）に遷移
		mv.setViewName("random");
		return mv;
	}
}