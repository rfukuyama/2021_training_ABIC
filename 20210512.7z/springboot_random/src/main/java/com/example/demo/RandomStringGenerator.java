package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;

@Service
public class RandomStringGenerator {

	// private final static int GENERATE_NUM = 10;

	/**
	 * ランダム文字列の生成
	 * 
	 * @param charLength 文字列の長さ
	 * @param withNumber 数字を含めるかどうか（true:含める false:含めない）
	 * @return ランダム文字列のリストを返す
	 */
	public List<String> generate(int charLength, boolean withNumber, boolean withAlphabet, String repet) {
		List<String> list = new ArrayList<>();
		if (repet == null || repet.length() == 0) {
			repet = "1";
		}
		int re = Integer.parseInt(repet);

		for (int i = 0; i < re; i++) {
			// 英数字
			if (withNumber && withAlphabet) {
				list.add(RandomStringUtils.randomAlphanumeric(charLength));
				// 数字のみ
			} else if (withNumber) {
				list.add(RandomStringUtils.randomNumeric(charLength));
				// 英字のみ
			} else if (withAlphabet) {
				list.add(RandomStringUtils.randomAlphabetic(charLength));
			} else {

			}
		}
		return list;
	}
}