package com.example.demo;

import java.util.Random;

public class Fortune {
	private int month;
	private String item;
	private String color;
	private int rank;

	String items[] = { "タオル", "カバン", "腕時計" };
	String colors[] = { "赤", "黄", "白" };
	Random rand = new Random();

	public Fortune(int month) {
		super();
		this.month = month;
		this.item = items[rand.nextInt(3)];
		this.color = colors[rand.nextInt(3)];
		this.rank = rand.nextInt(12) + 1;
	}

	public int getMonth() {
		return month;
	}

	public String getItem() {
		return item;
	}

	public String getColor() {
		return color;
	}

	public int getRank() {
		return rank;
	}
}
