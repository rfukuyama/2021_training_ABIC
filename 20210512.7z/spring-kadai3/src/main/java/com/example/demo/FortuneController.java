package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class FortuneController {

	@RequestMapping("/")
	public String index() {
		return "fortune";
	}

	@RequestMapping("/fortune")
	public ModelAndView fortune(@RequestParam("month") int month, ModelAndView mv) {
		Fortune result = new Fortune(month);
		mv.addObject("result", result);
		// mv.addObject("item", item);
		// mv.addObject("color", color);
		// mv.addObject("rank", rank);
		return mv;
	}
}
