package com.example.demo;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class AgeService {
	private LocalDate birthday;
	private LocalDate today;
	
	public AgeService(int year, int month, int day) {
		this.birthday = LocalDate.of(year, month, day);
		this.today = LocalDate.now();
	}

	public long calcAge() {
		long duration = ChronoUnit.YEARS.between(birthday, today);
		return duration;
	}

	public long calcDayCount() {
		long duration = ChronoUnit.DAYS.between(birthday, today);
		return duration;
	}

	public String getBirthday() {
		return	birthday.getYear() + "年" +
				birthday.getMonthValue() + "月" +
				birthday.getDayOfMonth() + "日";
	}

}
