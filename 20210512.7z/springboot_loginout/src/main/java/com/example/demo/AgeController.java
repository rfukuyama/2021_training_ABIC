package com.example.demo;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AgeController {

	@Autowired
	HttpSession session; 
	
	@RequestMapping(value="/calcAge")
	public ModelAndView calcAge(
			@RequestParam(name = "year", defaultValue = "2000") int year,
			@RequestParam(name = "month", defaultValue = "1") int month,
			@RequestParam(name = "day", defaultValue = "1") int day,
			ModelAndView mv
	) {
		AgeService srv = new AgeService(year, month, day);
		mv.addObject("age", srv.calcAge());
		mv.addObject("dayCount", srv.calcDayCount());
		mv.addObject("birthday", srv.getBirthday());
		
		mv.addObject("name", session.getAttribute("name"));

		mv.setViewName("result");
		return mv;
	}
}
