package com.example.demo;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class CheckLoginAspect {
	@Autowired
	HttpSession session;
	
	@Before("execution(* *..AgeController.*(..))")
	public void checkLogin(JoinPoint jp) {
		String name = (String)session.getAttribute("name");
		if(name == null || name.length() == 0) {
			System.err.println("ログインしていません！");
		}
	}
}
