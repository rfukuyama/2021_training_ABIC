package com.example.demo;

import java.util.Random;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class OmikujiController {

	@RequestMapping(value = "/omikuji", method = RequestMethod.POST)
	public ModelAndView omikuji(ModelAndView mv, @RequestParam("name") String name) {
		mv.setViewName("omikujiResult");

		if (name.length() == 0) {
			name = "ゲスト";
		}

		Random rand = new Random();
		String result;
		while (true) {
			int fortune = rand.nextInt(6) + 1;
			if (fortune == 1) {
				result = "大吉";
			} else if (fortune == 2) {
				result = "凶";
			} else if (fortune == 3) {
				result = "小吉";
			} else {
				result = "吉";
			}
			mv.addObject("result", result);
			mv.addObject("name", name);
			return mv;
		}
	}

}
