package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ItemController {

	@Autowired
	HttpSession session;

	@Autowired
	ItemRepository itemRepository;

	@RequestMapping(value = "/items")
	public ModelAndView items(@RequestParam(name = "sort", defaultValue = "price_asc") String sort,
			@RequestParam(name = "min_price", defaultValue = "0") int minPrice,
			@RequestParam(name = "max_price", defaultValue = "2147483647") int maxPrice, ModelAndView mv) {

		List<Item> itemList = new ArrayList<Item>();

		if (minPrice == 0 && maxPrice == 2147483647) {
			mv.addObject("minPrice", "");
			mv.addObject("maxPrice", "");
		} else if (minPrice == 0) {
			mv.addObject("minPrice", "");
			mv.addObject("maxPrice", maxPrice);
		} else if (maxPrice == 2147483647) {
			mv.addObject("minPrice", minPrice);
			mv.addObject("maxPrice", "");
		} else {
			mv.addObject("minPrice", minPrice);
			mv.addObject("maxPrice", maxPrice);
		}

		if (minPrice != 0 && maxPrice != 0 && sort.equals("price_asc")) {
			itemList = itemRepository.findByPriceBetweenOrderByPriceAsc(minPrice, maxPrice);
		} else if (minPrice != 0 && maxPrice != 0 && sort.equals("price_desc")) {
			itemList = itemRepository.findByPriceBetweenOrderByPriceDesc(minPrice, maxPrice);
		} else if (minPrice != 0 && sort.equals("price_asc")) {
			itemList = itemRepository.findByPriceGreaterThanEqualOrderByPriceAsc(minPrice);
		} else if (minPrice != 0 && sort.equals("price_desc")) {
			itemList = itemRepository.findByPriceGreaterThanEqualOrderByPriceDesc(minPrice);
		} else if (maxPrice != 0 && sort.equals("price_asc")) {
			itemList = itemRepository.findByPriceLessThanEqualOrderByPriceAsc(maxPrice);
		} else if (maxPrice != 0 && sort.equals("price_desc")) {
			itemList = itemRepository.findByPriceLessThanEqualOrderByPriceDesc(maxPrice);
		} else if (sort.equals("price_asc") || sort == null || sort.length() == 0) {
			itemList = itemRepository.findAllByOrderByCodeAsc();
		} else {
			itemList = itemRepository.findAllByOrderByCodeDesc();
		}

		mv.addObject("items", itemList);

		mv.setViewName("items");
		return mv;
	}

}
