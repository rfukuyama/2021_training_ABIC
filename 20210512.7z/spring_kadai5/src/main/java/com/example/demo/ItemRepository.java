package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemRepository extends JpaRepository<Item, Integer> {

	List<Item> findAllByOrderByCodeAsc();

	List<Item> findAllByOrderByCodeDesc();

	List<Item> findByPriceGreaterThanEqual(Integer minPrice);

	List<Item> findByPriceLessThanEqual(Integer maxPrice);

	List<Item> findByPriceBetween(Integer minPrice, Integer maxPrice);

	List<Item> findByPriceBetweenOrderByPriceAsc(int minPrice, int maxPrice);

	List<Item> findByPriceBetweenOrderByPriceDesc(int minPrice, int maxPrice);

	List<Item> findByPriceGreaterThanEqualOrderByPriceAsc(int minPrice);

	List<Item> findByPriceGreaterThanEqualOrderByPriceDesc(int minPrice);

	List<Item> findByPriceLessThanEqualOrderByPriceAsc(int maxPrice);

	List<Item> findByPriceLessThanEqualOrderByPriceDesc(int maxPrice);

}
