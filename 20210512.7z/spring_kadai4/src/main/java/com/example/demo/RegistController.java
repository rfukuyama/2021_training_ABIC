package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegistController {
	@Autowired
	HttpSession session;

	@RequestMapping("/")
	public String gotoTop() {
		return "top";
	}

	// ログイン
	@RequestMapping("/login")
	public String gotoLogin() {
		return "login";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam(name = "userId", defaultValue = "") String userId,
			@RequestParam(name = "password", defaultValue = "") String password, ModelAndView mv) {

		if (userId == null || userId.length() == 0 || password == null || password.length() == 0) {
			mv.addObject("message", "未入力の項目があります");
			mv.setViewName("login");
			return mv;
		}

		@SuppressWarnings("unchecked")
		List<User> userList = (List<User>) session.getAttribute("userList");
		if (userList == null) {
			userList = new ArrayList<User>();
			session.setAttribute("userList", userList);
		}

		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserId().equals(userId) && userList.get(i).getPassword().equals(password)) {
				mv.setViewName("main");
				session.setAttribute("loginUser", userList.get(i).getUserName());
				return mv;
			}
		}

		mv.addObject("message", "ユーザIDとパスワードが一致しませんでした");
		mv.setViewName("login");

		return mv;
	}

	// 登録
	@RequestMapping("/signup")
	public String gotoSignup() {
		return "signup";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView signup(@RequestParam(name = "userId", defaultValue = "") String userId,
			@RequestParam(name = "userName", defaultValue = "") String userName,
			@RequestParam(name = "password", defaultValue = "") String password, ModelAndView mv) {

		if (userId == null || userId.length() == 0 || userName == null || userName.length() == 0 || password == null
				|| password.length() == 0) {
			mv.addObject("message", "未入力の項目があります");
			mv.setViewName("signup");
			return mv;
		}

		@SuppressWarnings("unchecked")
		List<User> userList = (List<User>) session.getAttribute("userList");
		if (userList == null) {
			userList = new ArrayList<User>();
		}

		for (int i = 0; i < userList.size(); i++) {
			if (userList.get(i).getUserId().equals(userId)) {
				mv.setViewName("signup");
				mv.addObject("message", "登録済みのユーザIDです");
				return mv;
			}
		}

		userList.add(new User(userId, userName, password));
		session.setAttribute("userList", userList);
		mv.addObject("message", "登録が完了しました");
		mv.setViewName("login");

		return mv;
	}

	// ログアウト
	@RequestMapping("/logout")
	public String logout() {
		session.setAttribute("loginUser", null);
		return "top";
	}

	// メイン
	@RequestMapping("/main")
	public String gotoMain() {
		return "main";
	}
}
